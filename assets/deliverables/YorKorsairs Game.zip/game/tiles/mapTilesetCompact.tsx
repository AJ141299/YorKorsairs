<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="mapTilesetCompact" tilewidth="128" tileheight="128" tilecount="24" columns="8">
 <image source="mapCompact.png" width="1024" height="384"/>
</tileset>
