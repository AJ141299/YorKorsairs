<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="mapTileset" tilewidth="128" tileheight="128" spacing="6" margin="2" tilecount="105" columns="15">
 <image source="map.png" width="2048" height="1024"/>
</tileset>
